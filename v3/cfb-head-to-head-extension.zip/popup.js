
const $ = (s) => document.querySelector(s);

const API_BASE = "https://api.collegefootballdata.com";

async function getApiKey() {
  const { apiKey } = await chrome.storage.sync.get(["apiKey"]);
  if (!apiKey) throw new Error("Missing API key. Click Settings to add your CollegeFootballData API key.");
  return apiKey;
}

function setLoading(isLoading) {
  $("#loader").style.display = isLoading ? "block" : "none";
}

function setOutput(html) {
  $("#output").innerHTML = html;
}

function range(start, end) {
  return Array.from({length: end - start + 1}, (_, i) => start + i);
}

async function initSelectors() {
  const now = new Date();
  const currentYear = now.getMonth() >= 6 ? now.getFullYear() : now.getFullYear() - 1; // CFB season spans fall
  const years = range(currentYear - 6, currentYear + 1).reverse();
  const yearSel = $("#year");
  years.forEach(y => {
    const opt = document.createElement("option");
    opt.value = y;
    opt.textContent = y;
    yearSel.appendChild(opt);
  });

  // Fill week 0-20 to cover Week 0 and conference titles/bowls
  const weekSel = $("#week");
  range(0, 20).forEach(w => {
    const opt = document.createElement("option");
    opt.value = w;
    opt.textContent = `Week ${w}`;
    weekSel.appendChild(opt);
  });

  const { defaultYear, defaultWeek } = await chrome.storage.sync.get(["defaultYear", "defaultWeek"]);
  if (defaultYear) yearSel.value = defaultYear;
  if (defaultWeek !== undefined) weekSel.value = defaultWeek;
  else {
    // Try to detect current week via /weeks
    try {
      const apiKey = await getApiKey();
      const res = await fetch(`${API_BASE}/weeks?year=${yearSel.value}&seasonType=regular`, {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      if (res.ok) {
        const weeks = await res.json();
        const today = new Date().toISOString().slice(0, 10);
        const current = weeks.find(w => today >= w.startDate && today <= w.endDate);
        if (current) weekSel.value = current.week;
      }
    } catch (e) {
      // ignore autodetect errors
    }
  }
}

async function api(path) {
  const apiKey = await getApiKey();
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { Authorization: `Bearer ${apiKey}` }
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API ${path} failed: ${res.status} ${res.statusText} — ${text}`);
  }
  return res.json();
}

function sanitizeTeamName(name) {
  return name.trim();
}

/** Find the game for a team in a given year/week/seasonType */
async function findGame(team, year, week, seasonType) {
  const encTeam = encodeURIComponent(team);
  // Filter at API for less data
  const games = await api(`/games?year=${year}&week=${week}&seasonType=${seasonType}&team=${encTeam}`);
  if (!games || !games.length) return null;
  // If multiple (e.g., FCS scrimmage edge cases), pick first
  return games[0];
}

/** Opponent for a game relative to team */
function getOpponent(game, team) {
  const isHome = (game.home_team || game.homeTeam) === team;
  const isAway = (game.away_team || game.awayTeam) === team;
  const home = game.home_team || game.homeTeam;
  const away = game.away_team || game.awayTeam;
  return {
    opponent: isHome ? away : home,
    venue: isHome ? "home" : (isAway ? "away" : "neutral"),
    home, away
  };
}

/** Try to get odds / lines */
async function getLines(year, week, team) {
  try {
    const data = await api(`/lines?year=${year}&week=${week}&team=${encodeURIComponent(team)}`);
    if (!data || !data.length) return null;
    // Choose the line with most recent spread if available
    const first = data[0];
    const lines = (first.lines || []).filter(l => l.spread !== null && l.formattedSpread !== null);
    if (!lines.length) return null;
    // Choose last line entry
    return lines[lines.length - 1];
  } catch {
    return null;
  }
}

/** Ratings: SRS and/or SP+ as available */
async function getRatings(year) {
  let srs = [];
  let sp = [];
  try { srs = await api(`/ratings/srs?year=${year}`); } catch {}
  try { sp = await api(`/ratings/sp?year=${year}`); } catch {}
  const byTeam = {};
  srs.forEach(r => {
    byTeam[r.team] = byTeam[r.team] || {};
    byTeam[r.team].srs = r.rating ?? r.srs ?? r.overall ?? null;
  });
  sp.forEach(r => {
    byTeam[r.team] = byTeam[r.team] || {};
    // Use SP+ overall if present
    byTeam[r.team].sp = r.sp ?? r.rating ?? r.overall ?? null;
    if (r.offense) byTeam[r.team].sp_off = r.offense;
    if (r.defense) byTeam[r.team].sp_def = r.defense;
  });
  return byTeam;
}

/** Season aggregate stats (offense/defense) */
async function getSeasonStats(year, team) {
  try {
    const stats = await api(`/stats/season?year=${year}&team=${encodeURIComponent(team)}`);
    if (!stats || !stats.length) return null;
    // API returns an array with objects including statName/category
    const byCat = { offense: {}, defense: {} };
    for (const s of stats) {
      if (s.category && s.statName) {
        const cat = s.category.toLowerCase();
        if (cat === "offense" || cat === "defense") {
          byCat[cat][s.statName] = s.stat ?? s.value ?? s.statValue ?? s.average ?? null;
        }
      }
    }
    return byCat;
  } catch {
    return null;
  }
}

function fmt(n, digits=1) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return Number(n).toFixed(digits);
}

/** Simple prediction model:
 * base = (ratingA - ratingB)
 * HFA = 2.0 points to the home team
 * if Vegas spread available, blend: pred = 0.6*base + 0.4*(-spread_from_home_perspective)
 */
function predict(game, ratings) {
  const home = game.home_team || game.homeTeam;
  const away = game.away_team || game.awayTeam;
  const rHome = ratings[home] || {};
  const rAway = ratings[away] || {};
  const baseRatingHome = (rHome.sp ?? rHome.srs ?? 0) - (rAway.sp ?? rAway.srs ?? 0);
  const HFA = 2.0; // modest home-field advantage
  let edgeHome = baseRatingHome + HFA;

  let vegasAdj = null;
  if (game.lineSpread !== undefined) {
    // If caller provided a pre-fetched line
    vegasAdj = -game.lineSpread; // spread is "home by X" => negative means home is favored
  }
  if (vegasAdj !== null) {
    edgeHome = 0.6 * edgeHome + 0.4 * vegasAdj;
  }

  const winner = edgeHome >= 0 ? home : away;
  const loser = winner === home ? away : home;
  const margin = Math.abs(edgeHome);
  return { winner, loser, edgeHome, margin };
}

function renderSummary({ game, oppInfo, ratings, homeStats, awayStats, line }) {
  const home = game.home_team || game.homeTeam;
  const away = game.away_team || game.awayTeam;
  const homeR = ratings[home] || {};
  const awayR = ratings[away] || {};
  const spreadText = line?.formattedSpread ? line.formattedSpread : (line?.spread !== undefined ? (line.spread >= 0 ? `+${line.spread}` : `${line.spread}`) : "N/A");
  const totalText = line?.overUnder ?? "N/A";

  const pred = predict({ ...game, lineSpread: (line?.spread ?? null) }, ratings);

  const badge = (text) => `<span class="badge">${text}</span>`;

  return `
    <div class="card">
      <div class="grid">
        <div>
          <div class="small muted">Home</div>
          <div><strong>${home}</strong></div>
        </div>
        <div class="vs">vs</div>
        <div>
          <div class="small muted">Away</div>
          <div><strong>${away}</strong></div>
        </div>
      </div>
      <div class="footer">
        <div class="muted small">${game.start_date || game.startDate ? new Date(game.start_date || game.startDate).toLocaleString() : ""}</div>
        <div class="muted small">${game.venue || (game.neutral_site ? "Neutral site" : (game.home_conference || ""))}</div>
      </div>
    </div>

    <div class="card">
      <div class="kpi">
        <div class="item"><div class="muted small">Home Rating (SP+/SRS)</div><div><strong>${fmt(homeR.sp ?? homeR.srs)} / ${fmt(homeR.srs)}</strong></div></div>
        <div class="item"><div class="muted small">Away Rating (SP+/SRS)</div><div><strong>${fmt(awayR.sp ?? awayR.srs)} / ${fmt(awayR.srs)}</strong></div></div>
        <div class="item"><div class="muted small">Vegas Spread</div><div><strong>${spreadText}</strong></div></div>
        <div class="item"><div class="muted small">Over/Under</div><div><strong>${totalText}</strong></div></div>
      </div>
      <div class="note">Ratings blended where available; SP+ preferred when present. Home-field advantage baked into prediction.</div>
    </div>

    <div class="card">
      <div class="grid">
        <div>
          <div class="muted small">Home Offense (select stats)</div>
          <div class="small">PPG: <strong>${fmt(homeStats?.offense?.PointsPerGame)}</strong></div>
          <div class="small">Yds/Play: <strong>${fmt(homeStats?.offense?.YardsPerPlay)}</strong></div>
          <div class="small">Succ Rate: <strong>${fmt(homeStats?.offense?.SuccessRate, 3)}</strong></div>
        </div>
        <div>
          <div class="muted small">Away Offense (select stats)</div>
          <div class="small">PPG: <strong>${fmt(awayStats?.offense?.PointsPerGame)}</strong></div>
          <div class="small">Yds/Play: <strong>${fmt(awayStats?.offense?.YardsPerPlay)}</strong></div>
          <div class="small">Succ Rate: <strong>${fmt(awayStats?.offense?.SuccessRate, 3)}</strong></div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="grid">
        <div>
          <div class="muted small">Home Defense (select stats)</div>
          <div class="small">PPG Allowed: <strong>${fmt(homeStats?.defense?.PointsPerGame)}</strong></div>
          <div class="small">Yds/Play Allowed: <strong>${fmt(homeStats?.defense?.YardsPerPlay)}</strong></div>
          <div class="small">Succ Rate Allowed: <strong>${fmt(homeStats?.defense?.SuccessRate, 3)}</strong></div>
        </div>
        <div>
          <div class="muted small">Away Defense (select stats)</div>
          <div class="small">PPG Allowed: <strong>${fmt(awayStats?.defense?.PointsPerGame)}</strong></div>
          <div class="small">Yds/Play Allowed: <strong>${fmt(awayStats?.defense?.YardsPerPlay)}</strong></div>
          <div class="small">Succ Rate Allowed: <strong>${fmt(awayStats?.defense?.SuccessRate, 3)}</strong></div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="winner">Prediction: ${badge(pred.winner)} by ~${fmt(pred.margin,1)} pts</div>
      <div class="small muted">Loser: ${pred.loser}</div>
      <div class="note">This is a lightweight model that blends team ratings and market spread when available. For entertainment only.</div>
    </div>
  `;
}

async function main() {
  await initSelectors();

  $("#openOptions").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  $("#findBtn").addEventListener("click", async () => {
    const team = sanitizeTeamName($("#teamInput").value);
    const year = parseInt($("#year").value, 10);
    const week = parseInt($("#week").value, 10);
    const seasonType = $("#seasonType").value;

    if (!team) {
      setOutput(`<div class="error">Please enter a team name.</div>`);
      return;
    }

    setLoading(true);
    setOutput("");

    try {
      const game = await findGame(team, year, week, seasonType);
      if (!game) {
        setOutput(`<div class="error">No game found for ${team} in Week ${week}, ${year} (${seasonType}).</div>`);
        setLoading(false);
        return;
      }
      const { opponent } = getOpponent(game, team);

      const [ratings, homeStats, awayStats, lineObj] = await Promise.all([
        getRatings(year),
        getSeasonStats(year, game.home_team || game.homeTeam),
        getSeasonStats(year, game.away_team || game.awayTeam),
        getLines(year, week, team).catch(() => null)
      ]);

      const html = renderSummary({
        game,
        oppInfo: opponent,
        ratings,
        homeStats,
        awayStats,
        line: lineObj
      });
      setOutput(html);
    } catch (e) {
      console.error(e);
      setOutput(`<div class="error">${e.message}</div>`);
    } finally {
      setLoading(false);
    }
  });
}

main();
